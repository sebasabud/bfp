'use strict';

var utils = require('../utils/writer.js');
var IntegrationObject = require('../service/IntegrationObjectService');

module.exports.consolidation_create_process_produccion_endoso_post = function consolidation_create_process_produccion_endoso_post (req, res, next, body) {
  IntegrationObject.consolidation_create_process_produccion_endoso_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.consolidation_create_process_produccion_riesgo_post = function consolidation_create_process_produccion_riesgo_post (req, res, next, body) {
  IntegrationObject.consolidation_create_process_produccion_riesgo_post(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
