'use strict';


/**
 * Recibir evaluación de producción
 *
 * body BodyIntegrationPE Integration Object (Producción-Endosos) (optional)
 * returns Response
 **/
exports.consolidation_create_process_produccion_endoso_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "moreInformation" : "moreInformation",
  "internal_id" : "internal_id",
  "httpMessage" : "httpMessage",
  "httpCode" : 0,
  "userFriendlyError" : "userFriendlyError"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Recibir evaluación de producción
 *
 * body BodyIntegrationPR Integration Object (Producción-Riesgo) (optional)
 * returns Response
 **/
exports.consolidation_create_process_produccion_riesgo_post = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "moreInformation" : "moreInformation",
  "internal_id" : "internal_id",
  "httpMessage" : "httpMessage",
  "httpCode" : 0,
  "userFriendlyError" : "userFriendlyError"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

